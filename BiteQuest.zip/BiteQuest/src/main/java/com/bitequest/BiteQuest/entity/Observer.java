package com.bitequest.BiteQuest.entity;

public interface Observer {
    void update(Cardapio cardapio);
}
